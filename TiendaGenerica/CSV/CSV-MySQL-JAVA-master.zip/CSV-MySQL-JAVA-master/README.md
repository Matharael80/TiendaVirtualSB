# CSV-MySQL-JAVA
Ejemplo sencillo de como leer un archivo CSV  para después insertarlo en una base de datos MySQL en JAVA
